-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2020 at 08:33 AM
-- Server version: 8.0.22
-- PHP Version: 7.3.22-(to be removed in future macOS)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `okudb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_info`
--

CREATE TABLE `customer_info` (
  `c_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `c_firstname` varchar(20) DEFAULT NULL,
  `c_lastname` varchar(20) DEFAULT NULL,
  `c_phonenum` varchar(15) DEFAULT NULL,
  `c_address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_data`
--

CREATE TABLE `invoice_data` (
  `id_id` int NOT NULL,
  `id_pd_id` int DEFAULT NULL,
  `id_od_id` int DEFAULT NULL,
  `id_cd_id` int DEFAULT NULL,
  `id_date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `order_data`
--

CREATE TABLE `order_data` (
  `od_id` int NOT NULL,
  `od_pd_id` int DEFAULT NULL,
  `od_product_id` int DEFAULT NULL,
  `od_product_qty` int DEFAULT NULL,
  `od_status` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `payment_data`
--

CREATE TABLE `payment_data` (
  `pd_id` int NOT NULL,
  `pd_amt` varchar(20) DEFAULT NULL,
  `pd_type` varchar(10) DEFAULT NULL,
  `pd_date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int NOT NULL,
  `product_type` varchar(10) DEFAULT NULL,
  `sp_id` int DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `product_category` varchar(20) DEFAULT NULL,
  `product_price` varchar(5) DEFAULT NULL,
  `product_desc` varchar(100) DEFAULT NULL,
  `product_stock` varchar(5) DEFAULT NULL,
  `product_image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `serviceprovider_info`
--

CREATE TABLE `serviceprovider_info` (
  `sp_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `sp_companyname` varchar(50) DEFAULT NULL,
  `sp_servicetype` varchar(15) DEFAULT NULL,
  `sp_info` varchar(500) DEFAULT NULL,
  `sp_companyaddress` varchar(100) DEFAULT NULL,
  `sp_status` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `user_name` varchar(10) DEFAULT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `user_type` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_info`
--
ALTER TABLE `customer_info`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `invoice_data`
--
ALTER TABLE `invoice_data`
  ADD PRIMARY KEY (`id_id`),
  ADD KEY `id_pd_id` (`id_pd_id`),
  ADD KEY `id_od_id` (`id_od_id`),
  ADD KEY `id_cd_id` (`id_cd_id`);

--
-- Indexes for table `order_data`
--
ALTER TABLE `order_data`
  ADD PRIMARY KEY (`od_id`),
  ADD KEY `od_pd_id` (`od_pd_id`),
  ADD KEY `od_product_id` (`od_product_id`);

--
-- Indexes for table `payment_data`
--
ALTER TABLE `payment_data`
  ADD PRIMARY KEY (`pd_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `sp_id` (`sp_id`);

--
-- Indexes for table `serviceprovider_info`
--
ALTER TABLE `serviceprovider_info`
  ADD PRIMARY KEY (`sp_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_info`
--
ALTER TABLE `customer_info`
  MODIFY `c_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33463;

--
-- AUTO_INCREMENT for table `invoice_data`
--
ALTER TABLE `invoice_data`
  MODIFY `id_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `order_data`
--
ALTER TABLE `order_data`
  MODIFY `od_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `payment_data`
--
ALTER TABLE `payment_data`
  MODIFY `pd_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `serviceprovider_info`
--
ALTER TABLE `serviceprovider_info`
  MODIFY `sp_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_info`
--
ALTER TABLE `customer_info`
  ADD CONSTRAINT `customer_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_data`
--
ALTER TABLE `invoice_data`
  ADD CONSTRAINT `invoice_data_ibfk_1` FOREIGN KEY (`id_cd_id`) REFERENCES `customer_info` (`c_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoice_data_ibfk_2` FOREIGN KEY (`id_od_id`) REFERENCES `order_data` (`od_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoice_data_ibfk_3` FOREIGN KEY (`id_pd_id`) REFERENCES `payment_data` (`pd_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_data`
--
ALTER TABLE `order_data`
  ADD CONSTRAINT `order_data_ibfk_1` FOREIGN KEY (`od_pd_id`) REFERENCES `payment_data` (`pd_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_data_ibfk_2` FOREIGN KEY (`od_product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`sp_id`) REFERENCES `serviceprovider_info` (`sp_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `serviceprovider_info`
--
ALTER TABLE `serviceprovider_info`
  ADD CONSTRAINT `serviceprovider_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
